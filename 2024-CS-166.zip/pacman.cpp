#include<iostream>
using namespace std;
main()
{
cout<<"       .::_ _ _::..    "<<endl;
cout<<"    .--------------."   <<endl;
cout<<"  .------------------." <<endl;
cout<<"  -----------------:. " <<endl;
cout<<" :------------::."      <<endl;
cout<<" ------------:."        <<endl;
cout<<" :--------------:.."    <<endl;
cout<<"  :-----------------:." <<endl;
cout<<"   .----------------:"  <<endl;
cout<<"     .:----------:.   " <<endl;

}