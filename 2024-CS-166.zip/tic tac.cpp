#include<iostream>
using namespace std;
void board();
int main()
{


board();
}
void board()
{ 
cout<<" ************************  "<<endl;
cout<<"    TIC TAC TOE  " <<endl;
cout<<" ************************"<<endl;
cout<<" Player 1 (X) . Player 2 (o)"<<endl;
cout<<""<<endl;
   cout<< "            |      |      "<<endl;
   cout<< "         X  |   O  |  X   "<<endl;
   cout<< "     _______|______|________ "<<endl;
   cout<< "            |      |        "<<endl;
   cout<< "         X  |   X  |   O    "<<endl;
   cout<< "     _______|______|________ "<<endl;
   cout<< "            |      |         "<<endl;
   cout<< "         X  |  X   |    O    "<<endl;
   cout<< "            |      |         "<<endl;





}