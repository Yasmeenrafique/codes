#include<iostream>
using namespace std;
main()
{
cout<<"--------------------------------------"<<endl;
cout<<""<<endl;
cout<<" o   ^__^                          "<<endl;
cout<<"  o  (oo)\\______________          "<<endl;
cout<<"     (__)\               )\/\      "<<endl;
cout<<"         ||----------w ||          "<<endl;
cout<<"         ||            ||          "<<endl;

}