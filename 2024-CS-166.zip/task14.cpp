#include<iostream>
using namespace std;
main()
{
system("color 90");
cout<<"     ' .__.                                            "<<endl;
cout<<"       '                ------'                          "<<endl;
cout<<"        ' . '!_ ......_/'.--' '                          "<<endl;
cout<<"           !           /                                "<<endl;
cout<<"           /()      () !       , ' ,-._                  "<<endl;
cout<<"          |)   .       ()!     /     _. '                 "<<endl;
cout<<"          |   _'_          ,; ' . <                      "<<endl;
cout<<"          ; ._ _       , ; |    > |                      "<<endl;
cout<<"         / ,       /  ,    | .-'.-'                    "<<endl;
cout<<"        (_/       (__/ , ; | .<'                       "<<endl;
cout<<"          !      ,       ;-'                          "<<endl;
cout<<"           >     !      /                           "<<endl;
cout<<"          (_ ,-''>    .'                             "<<endl;
cout<<"             (_,'                                    "<<endl;


}
