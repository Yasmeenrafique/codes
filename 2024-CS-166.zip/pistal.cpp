#include<iostream>
using namespace std;
main()
{
system( " color2" );
cout<<"+---^------------,----------,---------,----------^-,"<<endl;
cout<<" |  ||||||||||    '-----------'        |            0"<<endl;
cout<<" ' +-----------------------------------^------------|"<<endl;
cout<<""<<endl;
cout<<"  ',----------,------------,-----------------------'  "<<endl;
cout<<"     / XXXXXX /'|           /'                        "<<endl;
cout<<"    / XXXXXX /  |          /'                           "<<endl;
cout<<"   / XXXXXX /'------------'                              "<<endl;
cout<<"  / XXXXXX /                                              "<<endl;
cout<<" / XXXXXX /                                              "<<endl;
cout<<"(--------(                                           "<<endl;
cout<<" '-------'                                               "<<endl;


}